<?PHP
require_once('core/CPS360_api.class.php');

CPS360_api::debug(false);
CPS360_api::redirect();